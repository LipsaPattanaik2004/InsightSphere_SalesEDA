# SalesAnalytics Pro

End-to-end data analysis project focused on sales data. Includes EDA, data cleaning,
feature engineering, visualizations and business insights. Place `sales_data.csv` in the `data/` folder.

Notebook: `sales_eda.ipynb`

Key sections:
- Data load & validation
- Exploratory Data Analysis (time series, region/product splits)
- Feature engineering (revenue, month/year extraction)
- Visualizations and insight summary
- Export cleaned dataset and summary reports

Tech: Python, Pandas, NumPy, Matplotlib, SQL (optional)
